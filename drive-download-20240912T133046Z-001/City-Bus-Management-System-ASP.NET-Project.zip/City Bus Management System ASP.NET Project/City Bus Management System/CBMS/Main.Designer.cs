﻿namespace City_bus_mgmt_system
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.routeManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.busStopsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.routeNoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopNoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopNameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fareSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tripInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.routeReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tktToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.routeManagementToolStripMenuItem,
            this.busDetailsToolStripMenuItem,
            this.busStopsToolStripMenuItem,
            this.tripInformationToolStripMenuItem,
            this.employeeDetailsToolStripMenuItem,
            this.accountToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.tktToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(660, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // routeManagementToolStripMenuItem
            // 
            this.routeManagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.editToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.routeManagementToolStripMenuItem.Name = "routeManagementToolStripMenuItem";
            this.routeManagementToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.routeManagementToolStripMenuItem.Text = "Route Management";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // busDetailsToolStripMenuItem
            // 
            this.busDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem1,
            this.deleteToolStripMenuItem1,
            this.editToolStripMenuItem1,
            this.exitToolStripMenuItem1});
            this.busDetailsToolStripMenuItem.Name = "busDetailsToolStripMenuItem";
            this.busDetailsToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.busDetailsToolStripMenuItem.Text = "Bus Details";
            // 
            // saveToolStripMenuItem1
            // 
            this.saveToolStripMenuItem1.Name = "saveToolStripMenuItem1";
            this.saveToolStripMenuItem1.Size = new System.Drawing.Size(116, 22);
            this.saveToolStripMenuItem1.Text = "Save";
            this.saveToolStripMenuItem1.Click += new System.EventHandler(this.saveToolStripMenuItem1_Click);
            // 
            // deleteToolStripMenuItem1
            // 
            this.deleteToolStripMenuItem1.Name = "deleteToolStripMenuItem1";
            this.deleteToolStripMenuItem1.Size = new System.Drawing.Size(116, 22);
            this.deleteToolStripMenuItem1.Text = "Delete";
            this.deleteToolStripMenuItem1.Click += new System.EventHandler(this.deleteToolStripMenuItem1_Click);
            // 
            // editToolStripMenuItem1
            // 
            this.editToolStripMenuItem1.Name = "editToolStripMenuItem1";
            this.editToolStripMenuItem1.Size = new System.Drawing.Size(116, 22);
            this.editToolStripMenuItem1.Text = "Edit";
            this.editToolStripMenuItem1.Click += new System.EventHandler(this.editToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(116, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            // 
            // busStopsToolStripMenuItem
            // 
            this.busStopsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.routeNoToolStripMenuItem,
            this.stopNoToolStripMenuItem,
            this.stopNameToolStripMenuItem,
            this.fareSToolStripMenuItem});
            this.busStopsToolStripMenuItem.Name = "busStopsToolStripMenuItem";
            this.busStopsToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.busStopsToolStripMenuItem.Text = "Bus Stops";
            // 
            // routeNoToolStripMenuItem
            // 
            this.routeNoToolStripMenuItem.Name = "routeNoToolStripMenuItem";
            this.routeNoToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.routeNoToolStripMenuItem.Text = "Save";
            this.routeNoToolStripMenuItem.Click += new System.EventHandler(this.routeNoToolStripMenuItem_Click);
            // 
            // stopNoToolStripMenuItem
            // 
            this.stopNoToolStripMenuItem.Name = "stopNoToolStripMenuItem";
            this.stopNoToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.stopNoToolStripMenuItem.Text = "Delete";
            this.stopNoToolStripMenuItem.Click += new System.EventHandler(this.stopNoToolStripMenuItem_Click);
            // 
            // stopNameToolStripMenuItem
            // 
            this.stopNameToolStripMenuItem.Name = "stopNameToolStripMenuItem";
            this.stopNameToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.stopNameToolStripMenuItem.Text = "Edit";
            this.stopNameToolStripMenuItem.Click += new System.EventHandler(this.stopNameToolStripMenuItem_Click);
            // 
            // fareSToolStripMenuItem
            // 
            this.fareSToolStripMenuItem.Name = "fareSToolStripMenuItem";
            this.fareSToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.fareSToolStripMenuItem.Text = "Exit";
            // 
            // tripInformationToolStripMenuItem
            // 
            this.tripInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem3,
            this.deleteToolStripMenuItem3,
            this.editToolStripMenuItem3});
            this.tripInformationToolStripMenuItem.Name = "tripInformationToolStripMenuItem";
            this.tripInformationToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.tripInformationToolStripMenuItem.Text = "Trip Information";
            // 
            // saveToolStripMenuItem3
            // 
            this.saveToolStripMenuItem3.Name = "saveToolStripMenuItem3";
            this.saveToolStripMenuItem3.Size = new System.Drawing.Size(116, 22);
            this.saveToolStripMenuItem3.Text = "Save";
            this.saveToolStripMenuItem3.Click += new System.EventHandler(this.saveToolStripMenuItem3_Click);
            // 
            // deleteToolStripMenuItem3
            // 
            this.deleteToolStripMenuItem3.Name = "deleteToolStripMenuItem3";
            this.deleteToolStripMenuItem3.Size = new System.Drawing.Size(116, 22);
            this.deleteToolStripMenuItem3.Text = "Delete";
            this.deleteToolStripMenuItem3.Click += new System.EventHandler(this.deleteToolStripMenuItem3_Click);
            // 
            // editToolStripMenuItem3
            // 
            this.editToolStripMenuItem3.Name = "editToolStripMenuItem3";
            this.editToolStripMenuItem3.Size = new System.Drawing.Size(116, 22);
            this.editToolStripMenuItem3.Text = "Edit";
            this.editToolStripMenuItem3.Click += new System.EventHandler(this.editToolStripMenuItem3_Click);
            // 
            // employeeDetailsToolStripMenuItem
            // 
            this.employeeDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEmployeeToolStripMenuItem,
            this.deleteEmployeeToolStripMenuItem,
            this.editEmployeeToolStripMenuItem});
            this.employeeDetailsToolStripMenuItem.Name = "employeeDetailsToolStripMenuItem";
            this.employeeDetailsToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.employeeDetailsToolStripMenuItem.Text = "Employee Details";
            // 
            // addEmployeeToolStripMenuItem
            // 
            this.addEmployeeToolStripMenuItem.Name = "addEmployeeToolStripMenuItem";
            this.addEmployeeToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.addEmployeeToolStripMenuItem.Text = "Add Employee";
            this.addEmployeeToolStripMenuItem.Click += new System.EventHandler(this.addEmployeeToolStripMenuItem_Click);
            // 
            // deleteEmployeeToolStripMenuItem
            // 
            this.deleteEmployeeToolStripMenuItem.Name = "deleteEmployeeToolStripMenuItem";
            this.deleteEmployeeToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.deleteEmployeeToolStripMenuItem.Text = "Delete Employee";
            this.deleteEmployeeToolStripMenuItem.Click += new System.EventHandler(this.deleteEmployeeToolStripMenuItem_Click);
            // 
            // editEmployeeToolStripMenuItem
            // 
            this.editEmployeeToolStripMenuItem.Name = "editEmployeeToolStripMenuItem";
            this.editEmployeeToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.editEmployeeToolStripMenuItem.Text = "Edit Employee";
            this.editEmployeeToolStripMenuItem.Click += new System.EventHandler(this.editEmployeeToolStripMenuItem_Click);
            // 
            // accountToolStripMenuItem
            // 
            this.accountToolStripMenuItem.Name = "accountToolStripMenuItem";
            this.accountToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.accountToolStripMenuItem.Text = "Schdule";
            this.accountToolStripMenuItem.Click += new System.EventHandler(this.accountToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountReportToolStripMenuItem,
            this.routeReportToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // accountReportToolStripMenuItem
            // 
            this.accountReportToolStripMenuItem.Name = "accountReportToolStripMenuItem";
            this.accountReportToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.accountReportToolStripMenuItem.Text = "Account Report";
            this.accountReportToolStripMenuItem.Click += new System.EventHandler(this.accountReportToolStripMenuItem_Click);
            // 
            // routeReportToolStripMenuItem
            // 
            this.routeReportToolStripMenuItem.Name = "routeReportToolStripMenuItem";
            this.routeReportToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.routeReportToolStripMenuItem.Text = "Route Report";
            this.routeReportToolStripMenuItem.Click += new System.EventHandler(this.routeReportToolStripMenuItem_Click);
            // 
            // tktToolStripMenuItem
            // 
            this.tktToolStripMenuItem.Name = "tktToolStripMenuItem";
            this.tktToolStripMenuItem.Size = new System.Drawing.Size(32, 20);
            this.tktToolStripMenuItem.Text = "tkt";
            this.tktToolStripMenuItem.Click += new System.EventHandler(this.tktToolStripMenuItem_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 300);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem routeManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem busDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem busStopsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem routeNoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopNoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopNameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fareSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tripInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem employeeDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem routeReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tktToolStripMenuItem;
    }
}