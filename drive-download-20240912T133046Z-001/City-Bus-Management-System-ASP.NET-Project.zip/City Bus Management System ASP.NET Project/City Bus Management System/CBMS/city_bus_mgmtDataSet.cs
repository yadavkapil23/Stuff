﻿namespace City_bus_mgmt_system {
    
    
    public partial class city_bus_mgmtDataSet {
    }
}

namespace City_bus_mgmt_system.city_bus_mgmtDataSetTableAdapters {
    
    
    public partial class accountTableAdapter {
    }
}
