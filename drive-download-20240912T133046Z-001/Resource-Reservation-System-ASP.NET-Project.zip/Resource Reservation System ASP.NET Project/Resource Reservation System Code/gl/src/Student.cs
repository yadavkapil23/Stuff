using System;

public class Student{
		
	public Student(){
		
	}
}
