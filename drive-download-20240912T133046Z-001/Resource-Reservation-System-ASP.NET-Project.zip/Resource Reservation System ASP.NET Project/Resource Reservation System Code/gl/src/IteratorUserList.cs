using System;

public interface IteratorUserList : Iterator<User>{
	int changeStatus(int index, int newState);
}
