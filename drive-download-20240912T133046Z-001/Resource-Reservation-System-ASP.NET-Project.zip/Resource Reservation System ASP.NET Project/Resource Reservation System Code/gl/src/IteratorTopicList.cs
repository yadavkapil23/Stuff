using System;

public interface IteratorTopicList : Iterator<Topic>{
	
}
