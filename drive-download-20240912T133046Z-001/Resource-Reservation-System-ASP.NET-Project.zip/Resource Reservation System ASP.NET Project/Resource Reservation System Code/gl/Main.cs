using System;
using Gtk;

public class MainClass{
	
	public static void Main(string[] args){
		new GUILogin();	
	}
}