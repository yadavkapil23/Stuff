<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<title>TONY_FEAR.COM</title>
	<link href="css/css.css" rel="stylesheet" type="text/css">
	<!-- THIS ESSENTIAL IN PLAYING FLASH -->
	<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
	<script type="text/javascript">
		function mhover(obj,txt){
			obj.src =txt;
		}
		function mout(obj,txt){
			obj.src =txt;
		}
	</script>
</head>

<body>

<!-- CONTAINER OF DIV'S -->
<div class="container">
	
	<!-- HEADER -->
	<div class="header">
	</div>
	
	<!-- NAVIGATOR -->
	<div class="navigator" align="center">
		<?php include 'includes/mainNav.txt'; ?>
	</div>
	
	<!-- MARQUEE INFO -->
	<div class="marqueeInfo">
		<?php include 'includes/Navmarquee.txt'; ?>
	</div>
	
	<!-- TEXT CONTAINER -->
	<div class="bodycontainer">
		<!-- Another div here for info-->
		
		<!-- CONTENTS -->
		<div class="Contents">
			<br><br><br>
			<div style="width:600px; height:400px; float:right; ">
				<table width="592" height="397" border="0" cellpadding="0" cellspacing="0" class="TNav">
                <tr>
                  <td width="52" height="60"><img src="images/icon_green_sd.gif" width="44" height="46"></td>
                  <td width="244">&nbsp;
				  	<a href="http://wampserver.com" >
						WAMP SERVER Download
					</a>
				  </td>
                  <td width="49"><img src="images/e19_java_ee_sdk.gif" width="46" height="38"></td>
                  <td width="247">&nbsp;
				  	<a href="http://java.com/en/download/index.jsp" >
				  		JAVA SDK Download
					</a>
				  </td>
                </tr>
                <tr>
                  <td height="63"><img src="images/logo_mysql_sun_a.gif" width="54" height="39"></td>
                  <td>&nbsp;
				  	<a href="http://dev.mysql.com/downloads/" >
						MYSQL Download
					</a>
				  </td>
                  <td><img src="images/VSEx.gif" width="56" height="33"></td>
                  <td>&nbsp;
				  	<a href="http://www.microsoft.com/express/download/" >
					</a><a href="http://www.csharp-station.com/Tutorial.aspx" >C# .NET Express</a>
				  </td>
                </tr>
                <tr>
                  <td height="68"><img src="images/c.jpg" width="48" height="48"></td>
                  <td>&nbsp;
					<a href="http://edn.embarcadero.com/article/21751" > 
						TURBO C++
					</a> 
				  </td>
                  <td><img src="images/VSEx.gif" width="56" height="33"></td>
                  <td>&nbsp;
				  	<a href="http://www.microsoft.com/express/download/" >
						VB .NET Express </a>
				  </td>
                </tr>
                <tr>
                  <td height="70"><img src="images/nb-logo.gif" width="43" height="37"></td>
                  <td>&nbsp;
				  	<a href="http://www.profsr.com/vb/vbintro.htm" >
						NETBEANS Download
					</a>
				  </td>
                  <td><img src="images/classic2.jpg" width="48" height="48"></td>
                  <td>&nbsp;
				  	<a href="http://www.profsr.com/vb/vbintro.htm" >
						ECLIPSE Download </a>
				  </td>
                </tr>
                <tr>
                  <td height="70"><img src="images/VSEx.gif" width="56" height="33"></td>
                  <td>&nbsp;
				  	<a href="http://www.microsoft.com/express/download/" >
						VWD Express </a>
				  </td>
                  <td><img src="images/sql_express_2008_site_logo_trans.gif" width="50" height="53"></td>
                  <td>&nbsp;
				  	<a href="http://www.microsoft.com/express/download/" >
						SQL SERVER Express </a>
				  </td>
                </tr>
                <tr>
                  <td height="66"><img src="images/icon_green_sd.gif" width="44" height="46"></td>
                  <td>&nbsp;
				  	<a href="http://www.postgresql.org/download/" >
						POSTGRESQL
					</a>
				  </td>
                  <td><img src="images/icon_green_sd.gif" width="44" height="46"></td>
                  <td>&nbsp;
				  	<a href="http://www.filehippo.com" >
						FILE HIPPO.COm</a>
				  </td>
		<td><img src="images/icon_green_sd.gif" width="44" height="46"></td>
                  <td>&nbsp;
				  	<a href="http://www.students3k.com" >
						STUDENTS3K.COm</a>
				  </td>
                </tr>
              </table>
			</div>
		</div>
		
		<!-- PERSONAL INFO -->
		<div class="PersonInfo" align="center">
			<img src="images/tony3.jpg" width="162" height="178" border="2"><br>
			  <br>
			<div class="inName">
				Winston Gubantes
			</div>
			<br>
		  	<div class="inOccupation" align="left">
				<?php include 'includes/infomarquee.txt'; ?>
		  	</div>
  	  </div>
	</div>
	
	
	<!-- FOOTER NAV-->
	<div class="footerNav" align="center" >
		<?php include 'includes/footernav.txt'; ?>
	</div>
	
	<!-- FOOTER -->
	<div class="footer" align="center" >
		Copyright � Genetic Computer Institute Davao All Rights Reserved 2009.
	</div>
	
</div>

</body>
</html>
