package com.dts.core.control;

import javax.servlet.http.HttpServlet;

public class UIController extends HttpServlet
{

}
