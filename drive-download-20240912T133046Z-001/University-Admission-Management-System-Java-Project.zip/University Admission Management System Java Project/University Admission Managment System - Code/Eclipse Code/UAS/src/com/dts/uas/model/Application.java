package com.dts.uas.model;

public class Application {
private String university;
private String applicationcourse;
private String startdate;
private String lastdate;
public String getUniversity() {
	return university;
}
public void setUniversity(String university) {
	this.university = university;
}
public String getApplicationcourse() {
	return applicationcourse;
}
public void setApplicationcourse(String applicationcourse) {
	this.applicationcourse = applicationcourse;
}
public String getStartdate() {
	return startdate;
}
public void setStartdate(String startdate) {
	this.startdate = startdate;
}
public String getLastdate() {
	return lastdate;
}
public void setLastdate(String lastdate) {
	this.lastdate = lastdate;
}
}
