<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>::. Build Bright University .::</title>
</head>

<body>
<div id="content">
	<div >
    	<img src="picture/master.jpg" width="805" height="308"  />
    </div>
    
    <div id="space"></div>
    
    <div id="question">
    	What do you know about Build Bright University?
    </div>
    
    <div id="space"></div>
    
    <div style="text-indent:40px; text-align:justify">
    Build Bright University (BBU) started as a non-profit organization called Cambodia Youth Volunteer Organization (CYVO) found and led by H.E. Dr. In Viracheat in 1998 providing trainings to Cambodian young professionals in Business, Management and English Language. From this humble beginning, it developed and became Faculty of Management and Law (FML) in 2000 with additional areas in Accounting, Finance, Human Resource Management, Computer and Law. From FML it has emerged to Build Bright University in 2002.

  </div>
</div><!--end of content -->
</body>
</html>