	</div>
	<div id="footer">
		 <?php 
		       include("footer.php"); 
		 ?>
	</div>
</div>
</body>
</html>
<?php exit; ?>