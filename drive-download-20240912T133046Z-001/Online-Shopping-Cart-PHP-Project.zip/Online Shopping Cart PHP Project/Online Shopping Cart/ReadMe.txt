Title: FreeWebshop.org
Description: This is a fully functional shopping cart script with: installation wizard, CSS template, order, product and customer management, full administration, the abillity to add custom payment portals (paypal and ideal included)

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
