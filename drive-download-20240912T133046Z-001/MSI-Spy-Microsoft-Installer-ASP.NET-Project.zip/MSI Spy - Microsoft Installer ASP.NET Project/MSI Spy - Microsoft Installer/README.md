msi-spy
=======

This is a project which helps you see every MSI which is installed on your machine.