
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_ChangePassword')
	BEGIN
		DROP Procedure spUsers_ChangePassword;
	END
GO
  
CREATE PROCEDURE dbo.spUsers_ChangePassword(
@InSNo numeric,
@InPassword varchar(50)
)
AS
 
Begin
    
        	update tblUsers set Password=@InPassword
			where SNo = @InSNo


End





  