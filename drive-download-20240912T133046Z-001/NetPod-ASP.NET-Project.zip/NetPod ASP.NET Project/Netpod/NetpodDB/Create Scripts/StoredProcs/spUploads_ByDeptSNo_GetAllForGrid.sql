GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUploads_ByDeptSNo_GetAllForGrid')
	BEGIN
		DROP  Procedure spUploads_ByDeptSNo_GetAllForGrid
	END
GO

Create Procedure dbo.spUploads_ByDeptSNo_GetAllForGrid(
@DeptsSNo numeric
)
AS
Begin

SELECT    L.*, U.UserName, D.DeptName
FROM      tblUploads L, tblUsers U, tblDepts D
WHERE     L.DeptsSNo=@DeptsSNo and 
		  L.UsersSNo=U.SNo and L.DeptsSNo=D.SNo

End
GO
    