GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spDepts_GetAllForDLL')
	BEGIN
		DROP  Procedure spDepts_GetAllForDLL
	END
GO

Create Procedure dbo.spDepts_GetAllForDLL
AS
Begin
	Select * from tblDepts;

End
GO
