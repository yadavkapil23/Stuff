GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_GetAllForSNo')
	BEGIN
		DROP  Procedure spUsers_GetAllForSNo
	END
GO

Create Procedure dbo.spUsers_GetAllForSNo(
@InSNo numeric
)
AS
Begin
	Select * from tblUsers where SNo=@InSNo;

End
GO
  