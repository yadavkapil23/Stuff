IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_GetData_ForConfidential')
	BEGIN
		DROP  Procedure  sp_GetData_ForConfidential
	END

GO

CREATE Procedure sp_GetData_ForConfidential
AS
		
SELECT Q1.SNo, Q1.OrgFileName, Q2.UserName AS SentBy , Q2.EmailID AS EmailIDBy , Q1.UserName AS SentTo, Q1.EmailID AS EmailIDTo
FROM  (SELECT    UL.OrgFileName, U.UserName, U.EmailID, UL.SNo
            FROM       tblUsers U, tblUploads UL, tblXUsersUploads UU
            WHERE     UU.UploadsSNo=UL.SNo and 
                             UU.UsersSNo=U.SNo and
                             DATEDIFF(d, UL.UploadedOn, GETDATE()) = 0) Q1,
           (SELECT     UL.OrgFileName, U.UserName, U.EmailID, UL.SNo
            FROM       tblXUsersUploads UU, tblUploads UL, tblUsers AS U
            WHERE     UU.UploadsSNo = UL.SNo and
                             UL.UsersSNo = U.SNo and 
                              DATEDIFF(d, UL.UploadedOn, GETDATE()) = 0) Q2
WHERE Q1.SNo=Q2.SNo
GROUP BY Q1.OrgFileName, Q1.UserName, Q2.EmailID, Q1.EmailID, Q2.UserName, Q1.SNo
ORDER BY Q1.SNo

GO


