
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_ChangeData')
	BEGIN
		DROP Procedure spUsers_ChangeData;
	END
GO


  
CREATE PROCEDURE dbo.spUsers_ChangeData(
@InSNo numeric output,
@InUserID varchar(50) output, 
@InPassword varchar(50),
@InUserName varchar(50), 
@InUserType varchar(50),
@InEmailID varchar(50),
@InGender varchar(1),
@InDOB datetime,
@InPhoneNo varchar(50),
@InAddress varchar(200),
@InFax varchar(50),
@InRecordStatus varchar(1),
@InCreatedDate datetime,
@InDeptsSNo numeric output
)
AS


 
Begin
	Declare @NewSNo int
	Declare @i int
	if @InSNo <= 0
		Begin
			Select SNo from tblUsers
			if @@RowCount <= 0 
				begin
					set @NewSNo = 1
					set @InSNo=@NewSNo
				end
			else
				Begin
					Select @NewSNo=max(SNo) + 1 from tblUsers
					print @NewSNo
					set @InSNo=@NewSNo
				end 
			set @InSNo=@NewSNo
			
   set @i=@InSNo
   
   set @InUserID=(char(@i / 26000 % 26 + 65) + 
    char(@i / 1000 % 26 + 65) + 
    char(@i / 100 % 10 + 48) + 
    char(@i / 10 % 10 + 48) + 
    char(@i % 10 + 48)) 
   
				Insert into tblUsers 
				(SNo, UserID, Password, UserName, UserType, EmailID, Gender, DOB, PhoneNo, Address, Fax, RecordStatus, CreatedDate, DeptsSNo)
				values 
				(@InSNo, @InUserID, @InPassword, @InUserName, @InUserType, @InEmailID, @InGender, @InDOB, @InPhoneNo, @InAddress, @InFax, @InRecordStatus, @InCreatedDate, @InDeptsSNo)
		end
	else
		begin
    
        	update tblUsers set UserID=@InUserID,Password=@InPassword, UserName=@InUserName, UserType=@InUserType, EmailID=@InEmailID, Gender=@InGender, DOB=@InDOB, PhoneNo=@InPhoneNo, Address=@InAddress, Fax=@InFax, RecordStatus=@InRecordStatus, CreatedDate=@InCreatedDate, DeptsSNo=@InDeptsSNo
			where SNo = @InSNo
			set @InSNo=@InSNo
		end
		



End





 