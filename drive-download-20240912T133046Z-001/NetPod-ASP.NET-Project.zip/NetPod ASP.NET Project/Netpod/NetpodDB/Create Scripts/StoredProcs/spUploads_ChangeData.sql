
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUploads_ChangeData')
	BEGIN
		DROP Procedure spUploads_ChangeData;
	END
GO


  
CREATE PROCEDURE dbo.spUploads_ChangeData(
@InSNo numeric output,
@InUsersSNo numeric,
@InDeptsSNo numeric,
@InOrgFileName varchar(50),
@InChangedFileName varchar(50) output,
@InConfidentiality varchar(1),
@InUploadedOn datetime
)
AS
 
Begin
	Declare @NewSNo int
	Declare @temp varchar(50)
	if @InSNo <= 0
		Begin
			Select SNo from tblUploads
			if @@RowCount <= 0 
				begin
					set @NewSNo = 1
					set @InSNo=@NewSNo
				end
			else
				Begin
					Select @NewSNo=max(SNo) + 1 from tblUploads
					print @NewSNo
					set @InSNo=@NewSNo
				end 
			set @InSNo=@NewSNo
			
   set @temp = convert(varchar(10),@InSNo) + @InChangedFileName
   set @InChangedFileName = @temp
   
   
				Insert into tblUploads 
				(SNo, UsersSNo, DeptsSNo, OrgFileName, ChangedFileName, Confidentiality, UploadedOn)
				values 
				(@InSNo, @InUsersSNo, @InDeptsSNo, @InOrgFileName, @InChangedFileName, @InConfidentiality, @InUploadedOn)
		end
	else
		begin
    
        	update tblUploads set UsersSNo=@InUsersSNo, DeptsSNo=@InDeptsSNo, OrgFileName=@InOrgFileName, ChangedFileName=@InChangedFileName, Confidentiality=@InConfidentiality, UploadedOn=@InUploadedOn
			where SNo = @InSNo
			set @InSNo=@InSNo
		end
		



End





 