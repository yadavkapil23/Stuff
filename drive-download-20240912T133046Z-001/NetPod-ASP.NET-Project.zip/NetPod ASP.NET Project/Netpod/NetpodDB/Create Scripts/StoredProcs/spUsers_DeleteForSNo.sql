GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_DeleteForSNo')
	BEGIN
		DROP  Procedure spUsers_DeleteForSNo
	END
GO

Create Procedure dbo.spUsers_DeleteForSNo(
@InSNo numeric
)
AS
Begin
Update tblUsers set RecordStatus='D' where SNo=@InSNo;

End
GO
   