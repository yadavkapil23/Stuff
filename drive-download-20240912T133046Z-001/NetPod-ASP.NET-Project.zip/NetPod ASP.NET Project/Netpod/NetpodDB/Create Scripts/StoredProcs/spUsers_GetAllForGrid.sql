GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_GetAllForGrid')
	BEGIN
		DROP  Procedure spUsers_GetAllForGrid
	END
GO

Create Procedure dbo.spUsers_GetAllForGrid
AS
Begin
	Select U.*, D.DeptName from tblUsers U,tblDepts D
	where U.DeptsSNo=D.SNo and RecordStatus='A';

End
GO
 