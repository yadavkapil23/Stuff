
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_ValidateUser')
	BEGIN
		DROP  Procedure spUsers_ValidateUser
	END
GO

Create Procedure dbo.spUsers_ValidateUser(@InUserID varchar(50), @InPassword Varchar(50))
AS
Begin
	Select * from tblUsers 
	Where UserID = @InUserID and 
	Password = @InPassword and RecordStatus='A';

End
GO
