GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUploads_BySNo_GetAllForGrid')
	BEGIN
		DROP  Procedure spUploads_BySNo_GetAllForGrid
	END
GO

Create Procedure dbo.spUploads_BySNo_GetAllForGrid(
@UsersSNo numeric,
@DeptsSNo numeric
)
AS
Begin

SELECT    L.*, U.UserName, D.DeptName
FROM      tblUploads L, tblUsers U, tblDepts D
WHERE     L.Confidentiality='N'  and L.DeptsSNo=@DeptsSNo and
		  L.UsersSNo=U.SNo and L.DeptsSNo=D.SNo
UNION
SELECT   L.*, U.UserName, D.DeptName
FROM     tblUploads L, tblUsers U, tblDepts D, tblXUsersUploads X
WHERE    L.SNo=X.UploadsSNo  and  L.Confidentiality='Y'  and L.DeptsSNo=@DeptsSNo and X.UsersSNo=@UsersSNo and
		 L.UsersSNo=U.SNo and L.DeptsSNo=D.SNo

End
GO
  