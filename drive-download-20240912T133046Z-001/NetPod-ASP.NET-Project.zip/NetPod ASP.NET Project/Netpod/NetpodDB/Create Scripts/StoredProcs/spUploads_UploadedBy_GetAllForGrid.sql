GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUploads_UploadedBy_GetAllForGrid')
	BEGIN
		DROP  Procedure spUploads_UploadedBy_GetAllForGrid
	END
GO

Create Procedure dbo.spUploads_UploadedBy_GetAllForGrid(
@UsersSNo numeric,
@DeptsSNo numeric
)
AS
Begin

SELECT    L.*, U.UserName, D.DeptName
FROM      tblUploads L, tblUsers U, tblDepts D
WHERE     L.DeptsSNo=@DeptsSNo and L.UsersSNo=@UsersSNo and
		  L.UsersSNo=U.SNo and L.DeptsSNo=D.SNo

End
GO
   