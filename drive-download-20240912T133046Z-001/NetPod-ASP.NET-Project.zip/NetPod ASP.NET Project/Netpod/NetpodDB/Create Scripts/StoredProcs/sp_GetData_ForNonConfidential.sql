IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'sp_GetData_ForNonConfidential')
	BEGIN
		DROP  Procedure  sp_GetData_ForNonConfidential
	END

GO

CREATE Procedure sp_GetData_ForNonConfidential

AS

SELECT UL.UsersSNo, UL.DeptsSNo, U.UserName as SentBy, U.EmailID 
EmailIDBy,UL.OrgFileName 
FROM     tblUsers U, tblUploads UL
WHERE U.SNO=UL.UsersSNo and UL.Confidentiality='N'

GO


 