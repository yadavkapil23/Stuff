GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_GetAllForGrid_DeletedUsers')
	BEGIN
		DROP  Procedure spUsers_GetAllForGrid_DeletedUsers
	END
GO

Create Procedure dbo.spUsers_GetAllForGrid_DeletedUsers
AS
Begin
	Select * from tblUsers where RecordStatus='D';

End
GO
  