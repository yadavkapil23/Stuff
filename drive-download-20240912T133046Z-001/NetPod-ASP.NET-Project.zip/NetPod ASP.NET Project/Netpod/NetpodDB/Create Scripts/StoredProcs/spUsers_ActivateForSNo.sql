GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_ActivateForSNo')
	BEGIN
		DROP  Procedure spUsers_ActivateForSNo
	END
GO

Create Procedure dbo.spUsers_ActivateForSNo(
@InSNo numeric
)
AS
Begin
Update tblUsers set RecordStatus='A' where SNo=@InSNo;

End
GO
    