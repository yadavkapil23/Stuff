GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spUsers_GetAllForLB_byDeptSNo')
	BEGIN
		DROP  Procedure spUsers_GetAllForLB_byDeptSNo
	END
GO

Create Procedure dbo.spUsers_GetAllForLB_byDeptSNo
(
@DeptSNo numeric
)
AS
Begin
	Select SNo,UserName from tblUsers
	where DeptsSNo=@DeptSNo and RecordStatus='A';

End
GO
  