--UploadFile.aspx functionname uploadusers
GO
IF EXISTS (SELECT * FROM sysobjects WHERE type = 'P' AND name = 'spXUsersUploads_Insert')
	BEGIN
		DROP Procedure spXUsersUploads_Insert;
	END
GO


  
CREATE PROCEDURE dbo.spXUsersUploads_Insert(
@InUploadsSNo numeric,
@InUsersSNo numeric
)
AS
 
Begin
   
				Insert into tblXUsersUploads
				(UploadsSNo, UsersSNo)
				values 
				(@InUploadsSNo, @InUsersSNo)

End





  