using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class User_UploadFile : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();
    static long CurUserSNo = 0;
    static long DeptSNo = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        lblDisplay.Text = "";

           if (Session["objCurUserInfo"] != null)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                CurUserSNo = objCurUserInfo.lngSNo;
                DeptSNo = objCurUserInfo.lngDeptSNo;
                if (objCurUserInfo.strUserType == "User")
                {
                    if (!IsPostBack)
                    {

                        LoadForm();
                    }
                }
                else
                    Response.Redirect("../Main/Home.aspx");
            }
            else
                Response.Redirect("../Main/Home.aspx");
        
    }

    protected void LoadForm()
    {
        try
        {

            objCommonFunctions.GetConnection(ref con);


            DataTable InDTItems = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForLB_byDeptSNo", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.Add("@DeptSNo", SqlDbType.Int).Value = DeptSNo;

            SqlDataReader dr;
            dr = sqlCmd.ExecuteReader();
            InDTItems.Load(dr);

            if (InDTItems.Rows.Count > 0)
            {
                InDTItems.DefaultView.RowFilter = "SNo <> " + CurUserSNo;
                lbUsers.DataSource = InDTItems;
                lbUsers.DataValueField = "SNo";
                lbUsers.DataTextField = "UserName";
                lbUsers.DataBind();
            }

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        Boolean boo = false;
        if (rbnSelectChoice.Checked == true)
        {
            foreach (ListItem li in lbUsers.Items)
            {
                if (li.Selected)
                {
                    boo = true;
                    break;
                }
            }
        }
        else
            boo = true;

        if (boo == true)
            SaveFile();
        else
            lblDisplay.Text = "Please Select Atleast One User<br>";
         
    }
    protected void SaveFile()
    {
        string strConfidentiality = "";

        for (int i = 1; i <= 10; i++)
        {
            FileUpload File = new FileUpload();
            File = (FileUpload)Page.Master.FindControl("ContentPlaceHolder1").FindControl("FileUpload"+i);
            if (File.PostedFile.FileName != "")
            {
                if (System.IO.File.Exists(File.PostedFile.FileName))
                {


                    if (rbnSelectAll.Checked)
                        strConfidentiality = "N";
                    else if (rbnSelectChoice.Checked)
                        strConfidentiality = "Y";
                    
                    //Save File in Upload Folder Begin
                    long lngUploadsSNo = 0;
                    UpLoadData(File,ref lngUploadsSNo, strConfidentiality);
                    lblDisplay.Text += "File " + System.IO.Path.GetFileName(File.PostedFile.FileName) + " Uploaded Successfully.<br>";
                    //Save File in Upload Folder End

                    if (strConfidentiality == "Y")
                    {

                        foreach (ListItem li in lbUsers.Items)
                        {
                            if (li.Selected)
                            {
                                UpLoadUsers(lngUploadsSNo,Convert.ToInt32(li.Value));
                            }
                        }
                    }
                }
                else
                {
                    lblDisplay.Text += "File " + System.IO.Path.GetFileName(File.PostedFile.FileName) + " Doesnot Exsit.<br>";
                }
            }
        }
    }

    protected void UpLoadData(FileUpload File, ref long lngUploadsSNo, string strConfidentiality)
    {
        try
        {
            string strOrgFileName = System.IO.Path.GetFileName(File.PostedFile.FileName);
            string strExtension = System.IO.Path.GetExtension(File.PostedFile.FileName);

            objCommonFunctions.GetConnection(ref con);


            DataTable InDTItems = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("spUploads_ChangeData", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;
            SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
            sqlCmd.Parameters.Add("@InUsersSNo", SqlDbType.Int).Value = CurUserSNo;
            sqlCmd.Parameters.Add("@InDeptsSNo", SqlDbType.Int).Value = DeptSNo;
            sqlCmd.Parameters.Add("@InOrgFileName", SqlDbType.VarChar, 50).Value = strOrgFileName;
            SqlParameter parChangedFileName = sqlCmd.Parameters.Add("@InChangedFileName", SqlDbType.VarChar, 50);
            sqlCmd.Parameters.Add("@InConfidentiality", SqlDbType.VarChar, 1).Value = strConfidentiality;
            sqlCmd.Parameters.Add("@InUploadedOn", SqlDbType.DateTime).Value = DateTime.Now;

            parSNo.Direction = ParameterDirection.InputOutput;
            parChangedFileName.Direction = ParameterDirection.InputOutput;

            parSNo.Value = lngUploadsSNo;
            parChangedFileName.Value = strExtension;

            sqlCmd.ExecuteNonQuery();

            lngUploadsSNo = Convert.ToInt32(parSNo.Value);

            string strChangedFileName = parChangedFileName.Value.ToString();

            //Save File in Uploads Folder Begin
            File.PostedFile.SaveAs(Server.MapPath("../Uploads/") + strChangedFileName);
            //Save File in Uploads Folder End
        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }
    }

    protected void UpLoadUsers(long lngUploadsSNo, long lngUsersSNo)
    {
        try
        {
            objCommonFunctions.GetConnection(ref con);

            DataTable InDTItems = new DataTable("tbl");

            //spXUsersUploads_Insert
            SqlCommand sqlCmd = new SqlCommand("Insert into tblXUsersUploads(UploadsSNo, UsersSNo) values(" + lngUploadsSNo + "," + lngUsersSNo + ")", con);
            
            //sqlCmd.CommandType = CommandType.StoredProcedure;
            //sqlCmd.Parameters.Add("@InUploadsSNo", SqlDbType.Int).Value = lngUploadsSNo;
            //sqlCmd.Parameters.Add("@InUsersSNo", SqlDbType.Int).Value = lngUsersSNo;

            sqlCmd.ExecuteNonQuery();
        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }
    }

    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (rbnSelectAll.Checked==true)
            lbUsers.Enabled = false;
        else
            lbUsers.Enabled = true;
    }

}
