using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_UserDetails : System.Web.UI.Page
{
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["objCurUserInfo"] != null)
            Page.MasterPageFile = "~/User/User.master";
        else
            Page.MasterPageFile = "~/Main/Main.master";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["UserID"] != null && Request.QueryString["Password"]!=null)
            {
                lblUserID.Text = Request.QueryString["UserID"];
                lblPassword.Text = Request.QueryString["Password"];
            }
            else
                Response.Redirect("../Main/Home.aspx");
        }
    }
}
