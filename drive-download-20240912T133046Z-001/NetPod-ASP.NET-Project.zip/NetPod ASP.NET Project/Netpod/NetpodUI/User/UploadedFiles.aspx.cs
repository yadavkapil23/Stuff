using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class User_UploadedFiles : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();
    static long CurUserSNo = 0;
    static long DeptSNo = 0;


    protected void Page_Load(object sender, EventArgs e)
    {
        lblDisplay.Text = "";

            if (Session["objCurUserInfo"] != null)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                CurUserSNo = objCurUserInfo.lngSNo;
                DeptSNo = objCurUserInfo.lngDeptSNo;
                if (objCurUserInfo.strUserType == "User")
                {
                    if (!IsPostBack)
                    {

                        LoadForm();
                    }
                }
                else
                    Response.Redirect("../Main/Home.aspx");
            }
            else
                Response.Redirect("../Main/Home.aspx");
  
    }
    public void LoadForm()
    {

        DataTable InDTItems = new DataTable();

        try
        {

            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl_ErrorLog");

            SqlCommand sqlCmd = new SqlCommand("spUploads_UploadedBy_GetAllForGrid", con);
            sqlCmd.Parameters.Add("@UsersSNo", SqlDbType.Int).Value = CurUserSNo;
            sqlCmd.Parameters.Add("@DeptsSNo", SqlDbType.Int).Value = DeptSNo;

            sqlCmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader drSource;
            drSource = sqlCmd.ExecuteReader();
            tblSource.Load(drSource);
            InDTItems = tblSource;

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }



        if (InDTItems.Rows.Count > 0)
        {
            dgDownload.Visible = true;
            dgDownload.DataSource = InDTItems;
            dgDownload.DataBind();
        }
        else
        {
            dgDownload.Visible = false;
            lblDisplay.Text += "<br> No Data Found To Display";
        }

    }

    protected void dgDownload_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        dgDownload.CurrentPageIndex = e.NewPageIndex;
        LoadForm();
    }
    protected void dgDownload_ItemCommand(object source, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
            //CurSNo = Convert.ToInt32(e.Item.Cells[0].Text);
            try
            {
                string OrgFileName = e.Item.Cells[1].Text;
                string ChgFileName = e.Item.Cells[2].Text;

                // Get the physical Path of the file(test.doc)
                string filepath = Server.MapPath("../Uploads/" + ChgFileName);

                // Create New instance of FileInfo class to get the properties of the file being downloaded
                FileInfo file = new FileInfo(filepath);

                // Checking if file exists
                if (file.Exists)
                {
                    // Clear the content of the response
                    Response.ClearContent();

                    // LINE1: Add the file name and attachment, which will force the open/cance/save dialog to show, to the header
                    Response.AddHeader("Content-Disposition", "attachment; filename=" + OrgFileName);

                    // Add the file size into the response header
                    Response.AddHeader("Content-Length", file.Length.ToString());

                    // Set the ContentType
                    Response.ContentType = "application/octet-stream";

                    // Write the file into the response (TransmitFile is for ASP.NET 2.0. In ASP.NET 1.1 you have to use WriteFile instead)
                    Response.TransmitFile(file.FullName);

                    // End the response
                    Response.End();

                    lblDisplay.Text = "Selected File is Succefully Downloaded.";
                }
                else
                    lblDisplay.Text = "Selected File Doesnot Exist.";
            }
            catch
            {
                lblDisplay.Text = "Error in the page";
            }
            finally
            {
                con.Close();
                con = null;
            }
            LoadForm();
        }

    }
}
