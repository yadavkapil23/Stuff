using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for clsCurUserInfo
/// </summary>
public class clsCurUserInfo
{
    public long lngSNo = 0;
    public string strUserID = "";
    public string strUserName = "";
    public string strPassword = "";
    public string strUserType = "";
    public long lngDeptSNo = 0;

    public clsCurUserInfo()
    {
     
      
    }
}
