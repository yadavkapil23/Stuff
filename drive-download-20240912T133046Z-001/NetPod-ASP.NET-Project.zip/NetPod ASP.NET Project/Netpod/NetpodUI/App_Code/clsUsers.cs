using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

   public class clsUsers
    {
        public long lngSNo=0;
	    public string strUserID="";
        public string strPassword = "";
        public string strAmount = "";
        public string strUserName = "";
        public string strUserType = "";
        public string strEmailID = "";
        public string strGender = "";
        public string datDOB = "";
        public string strPhoneNo = "";
        public string strAddress = "";
        public string strFax = "";
        public string strRecordStatus = "";
        public string datCreatedDate = "";

       public void ChangePassword()
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_ChangePassword", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
               SqlParameter parPassword = sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50);

               parSNo.Value = lngSNo;
               parPassword.Value = strPassword;

               sqlCmd.ExecuteNonQuery();

               //    ChangePassword = True
           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }

        public void ChangeData()
        {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con  = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

                   DataTable tblSource = new DataTable("tbl_ErrorLog");

                  SqlCommand sqlCmd = new SqlCommand("spUsers_ChangeData", con);

                  sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
               SqlParameter parUserID = sqlCmd.Parameters.Add("@InUserID", SqlDbType.VarChar, 50);
               SqlParameter parPassword = sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50);
               SqlParameter parAmount = sqlCmd.Parameters.Add("@InAmount", SqlDbType.VarChar, 50);
               SqlParameter parUserName = sqlCmd.Parameters.Add("@InUserName", SqlDbType.VarChar, 50);
               SqlParameter parEmailID = sqlCmd.Parameters.Add("@InEmailID", SqlDbType.VarChar, 50);
               SqlParameter parGender = sqlCmd.Parameters.Add("@InGender", SqlDbType.VarChar);
               SqlParameter parDOB = sqlCmd.Parameters.Add("@InDOB", SqlDbType.DateTime);
               SqlParameter parPhoneNo = sqlCmd.Parameters.Add("@InPhoneNo", SqlDbType.VarChar, 50);
               SqlParameter parAddress = sqlCmd.Parameters.Add("@InAddress", SqlDbType.VarChar, 200);
               SqlParameter parFax = sqlCmd.Parameters.Add("@InFax", SqlDbType.VarChar, 50);
               SqlParameter parRecordStatus = sqlCmd.Parameters.Add("@InRecordStatus", SqlDbType.VarChar);
               SqlParameter parCreatedDate = sqlCmd.Parameters.Add("@InCreatedDate", SqlDbType.DateTime);

               parSNo.Direction = ParameterDirection.InputOutput;
               parUserID.Direction = ParameterDirection.InputOutput;

                   parSNo.Value= lngSNo;
                   parUserID.Value = strUserID;
                   parPassword.Value = strPassword;
                   parUserName.Value = strUserName;
                   parAmount.Value = strAmount;
                   parEmailID.Value = strEmailID;
                   parGender.Value = strGender;
                   parDOB.Value = datDOB;
                   parPhoneNo.Value = strPhoneNo;
                   parAddress.Value = strAddress;
                   parFax.Value = strFax;
                   parRecordStatus.Value = strRecordStatus;
                   parCreatedDate.Value = datCreatedDate;

                   sqlCmd.ExecuteNonQuery();

                   lngSNo=Convert.ToInt32(parSNo.Value);
                   strUserID = parUserID.Value.ToString();

               //    ChangeData = True
           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

        }

        public void ValidateUser(ref DataTable InDTItems)
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_ValidateUser", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

              
               SqlParameter parUserID = sqlCmd.Parameters.Add("@InUserID", SqlDbType.VarChar, 50);
               SqlParameter parPassword = sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50);
             

                  
               parUserID.Value = strUserID;
               parPassword.Value = strPassword;
             
               		SqlDataReader drSource;
			drSource = sqlCmd.ExecuteReader();
			tblSource.Load(drSource);
			InDTItems = tblSource;

      
           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }


       public void GetAllForGrid(ref DataTable InDTItems)
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForGrid", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlDataReader drSource;
               drSource = sqlCmd.ExecuteReader();
               tblSource.Load(drSource);
               InDTItems = tblSource;

           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }

       public void GetAllForGrid_DeletedUsers(ref DataTable InDTItems)
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForGrid_DeletedUsers", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlDataReader drSource;
               drSource = sqlCmd.ExecuteReader();
               tblSource.Load(drSource);
               InDTItems = tblSource;

           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }

       public void GetAllForSNo(ref DataTable InDTItems)
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForSNo", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
               parSNo.Value = lngSNo;

               SqlDataReader drSource;
               drSource = sqlCmd.ExecuteReader();
               tblSource.Load(drSource);
               InDTItems = tblSource;

           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }

       public void DeleteForSNo()
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_DeleteForSNo", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
               parSNo.Value = lngSNo;

               sqlCmd.ExecuteNonQuery();

           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }


       public void ActivateForSNo()
       {

           clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
           SqlConnection con = new SqlConnection();

           try
           {

               objCommonFunctions.GetConnection(ref con);

               DataTable tblSource = new DataTable("tbl_ErrorLog");

               SqlCommand sqlCmd = new SqlCommand("spUsers_ActivateForSNo", con);

               sqlCmd.CommandType = CommandType.StoredProcedure;

               SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
               parSNo.Value = lngSNo;

               sqlCmd.ExecuteNonQuery();

           }
           catch
           {

               //Catch ex As Exception
           }
           finally
           {
               con.Close();
               con = null;
           }

       }

    }

