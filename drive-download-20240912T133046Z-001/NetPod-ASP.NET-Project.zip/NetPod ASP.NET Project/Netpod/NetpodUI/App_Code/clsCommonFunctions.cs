using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;


   public class clsCommonFunctions
    {

        public void GetConnection(ref SqlConnection InConn)
        {


            String strConnectionString = "Data Source=ipog-a95e1056d3;Initial Catalog=Netpod;User ID=sa;Password=sqlserver";

            try
            {
                InConn = new SqlConnection(strConnectionString);
                InConn.Open();

            }
            catch
            {

            }
        }


       public string SendEmail(string strSubject, string strBody, string strFrom, string strTo)
       {
           try
           {
               System.Web.Mail.MailMessage mail = new System.Web.Mail.MailMessage();
               mail.To = strTo;
               mail.From = strFrom;
               mail.Subject = strSubject;
               mail.Body = strBody;

               //System.Web.MailSmtpMail.SmtpServer = "mail.mycompany.com";  //your real server goes here
               System.Web.Mail.SmtpMail.Send(mail);
               return "Message Sent To " + strTo;
           }
           catch
           {
               return "Message Not Sent To " + strTo;
               //return "Please. Try After Sometime";
           }
       }

       public string SendGmail(string strSubject, string strBody, string strFrom, string strTo, string strLoginID, string strPassword)
       {
           try
           {
               System.Net.Mail.MailMessage objMM = new System.Net.Mail.MailMessage();
               System.Net.Mail.SmtpClient ObjSmtpMail = new System.Net.Mail.SmtpClient();//"smtp.gmail.com");


               objMM.To.Add(strTo);
               objMM.From = new System.Net.Mail.MailAddress(strFrom);
               objMM.IsBodyHtml = true;
               objMM.Priority = System.Net.Mail.MailPriority.Normal;
               objMM.Subject = strSubject;
               objMM.Body = strBody;

               ObjSmtpMail.Credentials = new System.Net.NetworkCredential(strLoginID, strPassword);
               ObjSmtpMail.Port = 587;
               ObjSmtpMail.Host = "smtp.gmail.com";
               ObjSmtpMail.EnableSsl = true;

               ObjSmtpMail.Send(objMM);
               return "Message Sent To " + strTo;
           }
           catch
           {
               return "Message Not Sent To " + strTo;
               //return "Please. Try After Sometime";
           }

       }
    }

