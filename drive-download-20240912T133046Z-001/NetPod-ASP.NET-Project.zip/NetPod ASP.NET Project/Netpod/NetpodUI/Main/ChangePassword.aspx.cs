using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Files_ChangePassword : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();
    static long CurSNo = 0;

    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["objCurUserInfo"] != null)
        {
            objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
            CurSNo = objCurUserInfo.lngSNo;
            if (objCurUserInfo.strUserType == "Admin")
                Page.MasterPageFile = "~/Admin/Admin.master";
            else if (objCurUserInfo.strUserType == "User")
                Page.MasterPageFile = "~/User/User.master";
            else
                Page.MasterPageFile = "~/Main/Main.master";
        }
        else
            Response.Redirect("../Main/Home.aspx");
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        lblError.Text = "";

        if (Session["objCurUserInfo"] != null)
        {
            if (!IsPostBack)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                CurSNo = objCurUserInfo.lngSNo;
            }
        }
        else
            Response.Redirect("../Main/Home.aspx");
         
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        ChangePassword();
    }


    protected void ChangePassword()
    {
    

        try
        {
            
            objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
            if (objCurUserInfo.strPassword == tbxOldPassword.Text)
            {
              
                try
                {

                    objCommonFunctions.GetConnection(ref con);

                    DataTable tblSource = new DataTable("tbl");

                    SqlCommand sqlCmd = new SqlCommand("spUsers_ChangePassword", con);

                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int).Value = CurSNo;
                    sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50).Value = tbxPassword.Text;
                    
                    sqlCmd.ExecuteNonQuery();


                    objCurUserInfo.strPassword = tbxPassword.Text;
                    Session["objCurUserInfo"] = objCurUserInfo;

                    Response.Redirect("../Main/Message.aspx?Message=Your Password Has Been Changed! Please Login");
                }
                catch
                {

                    //Catch ex As Exception
                }
                finally
                {
                    con.Close();
                    con = null;
                }

            }
            else
                lblError.Text = "Your Old Password is Incorrect";
        }
        catch
        {
            //handle exception
        }
    }
   
}
