using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Main_EditProfile : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();
    static long CurSNo = 0;
    
    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["objCurUserInfo"] != null)
        {
           objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                CurSNo = objCurUserInfo.lngSNo;
                if (objCurUserInfo.strUserType == "Admin")
                    Page.MasterPageFile = "~/Admin/Admin.master";
                else if (objCurUserInfo.strUserType == "User")
                    Page.MasterPageFile = "~/User/User.master";
                else
                    Page.MasterPageFile = "~/Main/Main.master";
         }
         else
             Response.Redirect("../Main/Home.aspx");
  
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["objCurUserInfo"] != null)
        {
            if (!IsPostBack)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                CurSNo = objCurUserInfo.lngSNo;

                LoadDepts();
                LoadForm();
            }
        }
        else
            Response.Redirect("Home.aspx");
    }

    protected void LoadDepts()
    {
        try
        {

            objCommonFunctions.GetConnection(ref con);


            DataTable tblSource = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("spDepts_GetAllForDLL", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;


            SqlDataReader dr;
            dr = sqlCmd.ExecuteReader();
            tblSource.Load(dr);

            if (tblSource.Rows.Count > 0)
            {
                ddlDept.DataSource = tblSource;
                ddlDept.DataValueField = "SNo";
                ddlDept.DataTextField = "DeptName";
                ddlDept.DataBind();
            }

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }
    }

    protected void LoadForm()
    {

        if (CurSNo != 0)
        {

            DataTable InDTItems = new DataTable();
            try
            {

                objCommonFunctions.GetConnection(ref con);

                DataTable tblSource = new DataTable("tbl_ErrorLog");

                SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForSNo", con);

                sqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
                parSNo.Value = CurSNo;

                SqlDataReader drSource;
                drSource = sqlCmd.ExecuteReader();
                tblSource.Load(drSource);
                InDTItems = tblSource;


                if (InDTItems.Rows.Count > 0)
                {
                    DateTime dt = new DateTime();
                    tbxUserID.Text = InDTItems.Rows[0]["UserID"].ToString();
                    tbxUserName.Text = InDTItems.Rows[0]["UserName"].ToString();
                    tbxPassword.Text = InDTItems.Rows[0]["Password"].ToString();
                    ddlUserType.Items.FindByText(InDTItems.Rows[0]["UserType"].ToString()).Selected = true;
                    tbxEmailID.Text = InDTItems.Rows[0]["EmailID"].ToString();
                    if (InDTItems.Rows[0]["Gender"].ToString() == "M")
                        rbnMale.Checked = true;
                    else
                        rbnFemale.Checked = true;
                    dt = Convert.ToDateTime(InDTItems.Rows[0]["DOB"].ToString());
                    tbxDOB.Text = dt.Month.ToString() + "/" + dt.Day.ToString() + "/" + dt.Year.ToString();
                    tbxAddress.Text = InDTItems.Rows[0]["Address"].ToString();
                    tbxPhone.Text = InDTItems.Rows[0]["PhoneNo"].ToString();
                    tbxFax.Text = InDTItems.Rows[0]["Fax"].ToString();
                    tbxCreatedDate.Text = InDTItems.Rows[0]["CreatedDate"].ToString();
                    ddlDept.Items.FindByValue(InDTItems.Rows[0]["DeptsSNo"].ToString()).Selected = true;
                }

            }
            catch
            {

                //Catch ex As Exception
            }
            finally
            {
                con.Close();
                con = null;
            }



        }

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        UpdateUserDetails();

    }

    protected void UpdateUserDetails()
    {
        long lngSNo = 0;
        string strUserID = "";

        if (CurSNo != 0)
        {
            try
            {

                objCommonFunctions.GetConnection(ref con);

                DataTable tblSource = new DataTable("tbl");

                SqlCommand sqlCmd = new SqlCommand("spUsers_ChangeData", con);

                sqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
                SqlParameter parUserID = sqlCmd.Parameters.Add("@InUserID", SqlDbType.VarChar, 50);
                sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50).Value = tbxPassword.Text;
                sqlCmd.Parameters.Add("@InUserName", SqlDbType.VarChar, 50).Value = tbxUserName.Text;
                sqlCmd.Parameters.Add("@InUserType", SqlDbType.VarChar, 50).Value = ddlUserType.SelectedItem.Text;
                sqlCmd.Parameters.Add("@InEmailID", SqlDbType.VarChar, 50).Value = tbxEmailID.Text;
                if (rbnMale.Checked == true)
                    sqlCmd.Parameters.Add("@InGender", SqlDbType.VarChar).Value = "M";
                else
                    sqlCmd.Parameters.Add("@InGender", SqlDbType.VarChar).Value = "F";

                sqlCmd.Parameters.Add("@InDOB", SqlDbType.DateTime).Value = tbxDOB.Text;
                sqlCmd.Parameters.Add("@InPhoneNo", SqlDbType.VarChar, 50).Value = tbxPhone.Text;
                sqlCmd.Parameters.Add("@InAddress", SqlDbType.VarChar, 200).Value = tbxAddress.Text;
                sqlCmd.Parameters.Add("@InFax", SqlDbType.VarChar, 50).Value = tbxFax.Text;
                sqlCmd.Parameters.Add("@InRecordStatus", SqlDbType.VarChar).Value = 'A';
                sqlCmd.Parameters.Add("@InCreatedDate", SqlDbType.DateTime).Value = DateTime.Now.ToString();
                sqlCmd.Parameters.Add("@InDeptsSNo", SqlDbType.Int).Value = ddlDept.SelectedItem.Value;

                parSNo.Direction = ParameterDirection.InputOutput;
                parUserID.Direction = ParameterDirection.InputOutput;

                parSNo.Value = CurSNo;
                parUserID.Value = tbxUserID.Text;

                sqlCmd.ExecuteNonQuery();

                lngSNo = Convert.ToInt32(parSNo.Value);
                strUserID = parUserID.Value.ToString();

              Response.Redirect("../Main/Message.aspx?Message=Your Profile Has Been Updated! Please Login.");
            }
            catch
            {

                //Catch ex As Exception
            }
            finally
            {
                con.Close();
                con = null;
            }

            Response.Redirect("../Main/Message.aspx?Message=Error: Please Try After Sometime");
        }

    }
}
