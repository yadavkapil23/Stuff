using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Main_Login : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblError.Text = "";
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {

        ValidateUser();
        
    }

    protected void ValidateUser()
    {
        clsCurUserInfo objCurUserInfo = new clsCurUserInfo();
        DataTable InDTItems = new DataTable();

        try
        {

            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("spUsers_ValidateUser", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;

            sqlCmd.Parameters.Add("@InUserID", SqlDbType.VarChar, 50).Value = tbxUserID.Text;
            sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50).Value = tbxPassword.Text;

            SqlDataReader drSource;
            drSource = sqlCmd.ExecuteReader();
            tblSource.Load(drSource);
            InDTItems = tblSource;


            if (InDTItems.Rows.Count > 0)
            {
                objCurUserInfo.lngSNo = Convert.ToInt32(InDTItems.Rows[0]["SNo"].ToString());
                objCurUserInfo.strUserID = InDTItems.Rows[0]["UserID"].ToString();
                objCurUserInfo.strUserName = InDTItems.Rows[0]["UserName"].ToString();
                objCurUserInfo.strPassword = InDTItems.Rows[0]["Password"].ToString();
                objCurUserInfo.strUserType = InDTItems.Rows[0]["UserType"].ToString();
                objCurUserInfo.lngDeptSNo = Convert.ToInt32(InDTItems.Rows[0]["DeptsSNo"].ToString());

                Session["objCurUserInfo"] = objCurUserInfo;

                if (objCurUserInfo.strUserType == "Admin")
                    Response.Redirect("../Admin/AdminDetails.aspx");
                else
                    Response.Redirect("../User/UserDetails.aspx?UserID=" + tbxUserID.Text + "&Password=" + tbxPassword.Text);
            }
            else
            {
                lblError.Text = "Invalid Login Details";
            }

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }

    }
}
