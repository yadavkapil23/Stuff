using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class Main_Register : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            LoadPage(); 
        
        }
    }

    protected void LoadPage()
    {
        try
        {

            objCommonFunctions.GetConnection(ref con);


            DataTable tblSource = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("spDepts_GetAllForDLL", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;


            SqlDataReader dr;
            dr = sqlCmd.ExecuteReader();
            tblSource.Load(dr);
            if (tblSource.Rows.Count > 0)
            {
                ddlDept.DataSource = tblSource;
                ddlDept.DataValueField = "SNo";
                ddlDept.DataTextField = "DeptName";
                ddlDept.DataBind();
            }

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {

        RegisterUser();
    }

    protected void RegisterUser()
    {
        long lngSNo = 0;
        string strUserID = "";


        try
        {

            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("spUsers_ChangeData", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;

            SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
            SqlParameter parUserID = sqlCmd.Parameters.Add("@InUserID", SqlDbType.VarChar, 50);
            sqlCmd.Parameters.Add("@InPassword", SqlDbType.VarChar, 50).Value = tbxPassword.Text;
            sqlCmd.Parameters.Add("@InUserName", SqlDbType.VarChar, 50).Value = tbxUserName.Text;
            sqlCmd.Parameters.Add("@InUserType", SqlDbType.VarChar, 50).Value = "User";
            sqlCmd.Parameters.Add("@InEmailID", SqlDbType.VarChar, 50).Value = tbxEmailID.Text;
            if (rbnMale.Checked == true)
                sqlCmd.Parameters.Add("@InGender", SqlDbType.VarChar).Value = "M";
            else
                sqlCmd.Parameters.Add("@InGender", SqlDbType.VarChar).Value = "F";

            sqlCmd.Parameters.Add("@InDOB", SqlDbType.DateTime).Value = tbxDOB.Text;
            sqlCmd.Parameters.Add("@InPhoneNo", SqlDbType.VarChar, 50).Value = tbxPhone.Text;
            sqlCmd.Parameters.Add("@InAddress", SqlDbType.VarChar, 200).Value = tbxAddress.Text;
            sqlCmd.Parameters.Add("@InFax", SqlDbType.VarChar, 50).Value = tbxFax.Text;
            sqlCmd.Parameters.Add("@InRecordStatus", SqlDbType.VarChar).Value = 'A';
            sqlCmd.Parameters.Add("@InCreatedDate", SqlDbType.DateTime).Value = DateTime.Now.ToString();
            sqlCmd.Parameters.Add("@InDeptsSNo", SqlDbType.Int).Value = ddlDept.SelectedItem.Value;

            parSNo.Direction = ParameterDirection.InputOutput;
            parUserID.Direction = ParameterDirection.InputOutput;

            parSNo.Value = lngSNo;
            parUserID.Value = strUserID;

            sqlCmd.ExecuteNonQuery();

            lngSNo = Convert.ToInt32(parSNo.Value);
            strUserID = parUserID.Value.ToString();

            Response.Redirect("../User/UserDetails.aspx?UserID=" + strUserID + "&Password=" + tbxPassword.Text);
        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }

        Response.Redirect("~/Main/Message.aspx?Message=Error: Please Try After Sometime");
        
    }

}
