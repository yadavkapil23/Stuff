using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_EmailSchedular : System.Web.UI.Page
{

    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();
    
    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();

    protected void Page_Load(object sender, EventArgs e)
    {

     
            if (Session["objCurUserInfo"] != null)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                if (objCurUserInfo.strUserType == "Admin")
                {
                    if (!IsPostBack)
                    {
                       // LoadForm();
                    }
                }
                else
                    Response.Redirect("../Main/Home.aspx");
            }
            else
                Response.Redirect("../Main/Home.aspx");
       

        lblMessage.Text = "";

    }
    protected void btnSend_Click(object sender, EventArgs e)
    {
        GetDataForNonConfidential();
        GetDataForConfidential();
    }

    protected void GetDataForNonConfidential()
    {
        DataTable InDTItems = new DataTable();

        try
        {
            
            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("sp_GetData_ForNonConfidential", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader drSource;
            drSource = sqlCmd.ExecuteReader();
            tblSource.Load(drSource);
            InDTItems = tblSource;

            foreach (DataRow dr in InDTItems.Rows)
            {
                DataTable DT = new DataTable();

                   DataTable tblSource1 = new DataTable("tbl");

                    string strQuery = "SELECT UserName as SentTo, EmailID  EmailIDTo FROM tblUsers WHERE SNo<>" + dr["UsersSNo"].ToString() + "  AND DeptsSNo=" + dr["DeptsSNo"].ToString();
                    SqlCommand sqlCmd1 = new SqlCommand(strQuery, con);

                    sqlCmd1.CommandType = CommandType.Text;

                    SqlDataReader drSource1;
                    drSource1 = sqlCmd1.ExecuteReader();
                    tblSource1.Load(drSource1);
                    DT = tblSource1;
     

                lblMessage.Text += "<br>Done For Non-Confidential. ";
                
                foreach (DataRow dr1 in DT.Rows)
                {
                    string strSentByUser = dr["SentBy"].ToString();
                    string strEmailByUser = dr["EmailIDBy"].ToString();
                    string strSentToUser = dr1["SentTo"].ToString();
                    string strEmailToUser = dr1["EmailIDTo"].ToString();
                    string strFileName = dr["OrgFileName"].ToString();
                    string strSubject = "File Upload....";
                    string strBody = "Hello! " + strSentToUser + ",<br><b>" + strFileName + "</b> was uploaded by <b>" + strSentByUser + "</b>.<br>Regards,<br><b>Netpod.</b>";
                    string strPassword = tbxPassword.Text;

                    lblMessage.Text += "<br>" + objCommonFunctions.SendGmail(strSubject, strBody, strEmailByUser, strEmailToUser, "vilas.veer@gmail.com", strPassword);
                }
            }

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }


    }

    protected void GetDataForConfidential()
    {
        DataTable InDTItems = new DataTable();

        try
        {

            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl");

            SqlCommand sqlCmd = new SqlCommand("sp_GetData_ForConfidential", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader drSource;
            drSource = sqlCmd.ExecuteReader();
            tblSource.Load(drSource);
            InDTItems = tblSource;

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }

        lblMessage.Text += "<br>Done For Confidential. ";

        foreach (DataRow dr in InDTItems.Rows)
        {
            string strSentByUser = dr["SentBy"].ToString();
            string strEmailByUser = dr["EmailIDBy"].ToString();
            string strSentToUser = dr["SentTo"].ToString();
            string strEmailToUser = dr["EmailIDTo"].ToString();
            string strFileName = dr["OrgFileName"].ToString();
            string strSubject = "File Upload....";
            string strBody = "Hello! " + strSentToUser + ",<br><b>" + strFileName + "</b> was uploaded by <b>" + strSentByUser + "</b>.<br>Regards,<br><b>Netpod.</b>";
            string strPassword = tbxPassword.Text;

            lblMessage.Text += "<br>" + objCommonFunctions.SendGmail(strSubject, strBody, strEmailByUser, strEmailToUser, "vilas.veer@gmail.com", strPassword);
        }
    }

}
