using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_UsersList : System.Web.UI.Page
{

    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();
 
    protected void Page_Load(object sender, EventArgs e)
    {
      
            if (Session["objCurUserInfo"] != null)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                if (objCurUserInfo.strUserType == "Admin")
                {
                    if (!IsPostBack)
                    {

                        LoadForm();
                    }
                }
                else
                    Response.Redirect("../Main/Home.aspx");
            }
            else
                Response.Redirect("../Main/Home.aspx");
      
    }

    public void LoadForm()
    {
    
        DataTable InDTItems = new DataTable();
 
        try
        {

            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl_ErrorLog");

            SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForGrid", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader drSource;
            drSource = sqlCmd.ExecuteReader();
            tblSource.Load(drSource);
            InDTItems = tblSource;

        }
        catch
        {

            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }



        if (InDTItems.Rows.Count > 0)
        {
            dgUsers.Visible = true;
            dgUsers.DataSource = InDTItems;
            dgUsers.DataBind();
        }
        else
        {
            dgUsers.Visible = false;
            lblDisplay.Text += "<br> No Data Found To Display";
        }
        //gvUsers.DataSource = InDTItems;
        //gvUsers.DataBind();
    }

    protected void dgUsers_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        dgUsers.CurrentPageIndex = e.NewPageIndex;
        LoadForm();
    }



    protected void dgUsers_ItemCommand(object source, DataGridCommandEventArgs e)
    {

        long CurSNo = 0;
        if (e.CommandName == "Edit")
        {
            CurSNo = Convert.ToInt32(e.Item.Cells[0].Text);
            Response.Redirect("UsersMaint.aspx?CurSNo=" + CurSNo);
        }
        else if (e.CommandName == "Delete")
        {
            CurSNo = Convert.ToInt32(e.Item.Cells[0].Text);
            try
            {

                objCommonFunctions.GetConnection(ref con);

                DataTable tblSource = new DataTable("tbl_ErrorLog");

                SqlCommand sqlCmd = new SqlCommand("spUsers_DeleteForSNo", con);

                sqlCmd.CommandType = CommandType.StoredProcedure;

                SqlParameter parSNo = sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int);
                parSNo.Value = CurSNo;

                sqlCmd.ExecuteNonQuery();


                lblDisplay.Text = "Selected User Succefully Deleted ";
            }
            catch
            {
                lblDisplay.Text = "Error in the page";
            }
            finally
            {
                con.Close();
                con = null;
            }
            LoadForm();
        }
    }

}