using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_DeletedUsers : System.Web.UI.Page
{
    clsCommonFunctions objCommonFunctions = new clsCommonFunctions();
    SqlConnection con = new SqlConnection();

    clsCurUserInfo objCurUserInfo = new clsCurUserInfo();

    protected void Page_Load(object sender, EventArgs e)
    {
        lblDisplay.Text = ""; 

        
            if (Session["objCurUserInfo"] != null)
            {
                objCurUserInfo = (clsCurUserInfo)Session["objCurUserInfo"];
                if (objCurUserInfo.strUserType == "Admin")
                {
                    if (!IsPostBack)
                    {
                    LoadForm();
                    }
                }
                else
                    Response.Redirect("../Main/Home.aspx");
            }
            else
                Response.Redirect("../Main/Home.aspx");
        
    }

    public void LoadForm()
    {
        DataTable InDTItems = new DataTable();
        try
        {

            objCommonFunctions.GetConnection(ref con);

            DataTable tblSource = new DataTable("tbl_ErrorLog");

            SqlCommand sqlCmd = new SqlCommand("spUsers_GetAllForGrid_DeletedUsers", con);

            sqlCmd.CommandType = CommandType.StoredProcedure;

            SqlDataReader drSource;
            drSource = sqlCmd.ExecuteReader();
            tblSource.Load(drSource);
            InDTItems = tblSource;


            if (InDTItems.Rows.Count > 0)
            {
                dgUsers.Visible = true;
                dgUsers.DataSource = InDTItems;
                dgUsers.DataBind();
            }
            else
            {
                dgUsers.Visible = false;
                lblDisplay.Text += "<br> No Data Found To Display";
            }
        }
        catch
        {
            lblDisplay.Text = "Error in the page";
            //Catch ex As Exception
        }
        finally
        {
            con.Close();
            con = null;
        }




    }


    protected void dgUsers_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
    {
        dgUsers.CurrentPageIndex = e.NewPageIndex;
        LoadForm();
    }
    protected void dgUsers_ItemCommand(object source, DataGridCommandEventArgs e)
    {
       
        long CurSNo = 0;
        if (e.CommandName == "Activate")
        {
            CurSNo = Convert.ToInt32(e.Item.Cells[0].Text);
          
            
                try
                {

                    objCommonFunctions.GetConnection(ref con);

                    DataTable tblSource = new DataTable("tbl");

                    SqlCommand sqlCmd = new SqlCommand("spUsers_ActivateForSNo", con);

                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    sqlCmd.Parameters.Add("@InSNo", SqlDbType.Int).Value = CurSNo;

                    sqlCmd.ExecuteNonQuery();


                    lblDisplay.Text = "Selected Users' Account is Succefully Activated ";
                }
                catch
                {
                    lblDisplay.Text = "Error in the page";
                    //Catch ex As Exception
                }
                finally
                {
                    con.Close();
                    con = null;
                }

         

            LoadForm();
        }
    }

 

}
