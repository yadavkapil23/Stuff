<?php

$allowed_files = array(
'php',
'asp',
'shtml',
'pdf',
'gif',
'jpg',
'png',
'doc',
'xls',
'sxw',
'jsp',
'css',
'mdb',
'txt',
'zip',
'tgz'
);

?>