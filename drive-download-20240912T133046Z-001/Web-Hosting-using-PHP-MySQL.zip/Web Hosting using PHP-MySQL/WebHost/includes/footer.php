<?php
if(isset($not_approved)){
	echo "<br /><br /><br /><center>$not_approved</center><br /><br /><br />";
}
echo "<br /><br />";
echo "<center>Powered by <a href=http://www.kasl.info target=blank>KASL WebHost</a> version $kwh_version<br />
Copyright &copy;2005 - <a href=http://www.kasl.info/ target=blank>kasl.info</a></center>";
?>

</body>
</html>
