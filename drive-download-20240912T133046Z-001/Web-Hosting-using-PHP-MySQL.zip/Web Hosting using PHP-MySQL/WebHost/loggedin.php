<?php

     include("includes/header.php");

    echo "<br /><br /><br /><b><center>You are now logged in as $name!<br /><br />
            <a href=http://www.kasl.info/profile_edit.php>Edit Your Profile</a></center></b>";

     include("includes/footer.php");

?>
