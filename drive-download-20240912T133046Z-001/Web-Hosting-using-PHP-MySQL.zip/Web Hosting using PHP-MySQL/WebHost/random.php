<script language="JavaScript">
<!--
function random_content(){
var mycontent=new Array()
mycontent[1]='<b><font color=#3F3FCF>TIP:</font></b> The default page shown at <?php echo $url; ?>/<?php echo $username; ?> is index.php.  If you delete the existing one and replace it with your own, your own will be the one to show up by default.'
mycontent[2]='<b><font color=#3F3FCF>TIP:</font></b> This server supports PHP.  If you create a page such as test.php, and then put the following code into your index.php page, the content of test.php will show up in index.php: &lt;?php include("index.php"); ?&gt;'
mycontent[3]='<b><font color=#3F3FCF>TIP:</font></b> If you need support, post your questions in the support forums at <a href=http://www.kasl.info/forum target=blank>www.kasl.info/forum</a>.'
mycontent[4]='<b><font color=#FF0000>NOTE:</font></b> If you find any bugs in this program, please report them at <a href=http://www.kasl.info/forum/topics.php?forum_id=5 target=blank>KASL Forums Bug Reports</a>.'

var ry=Math.floor(Math.random()*mycontent.length)
if (ry==0)
ry=1
document.write(mycontent[ry])
}
random_content()
//-->
</script>
