// PL lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Znajdz',
searchreplace_searchnext_desc : 'Znajdz ponownie',
searchreplace_replace_desc : 'Znajdz/Zastap',
searchreplace_notfound : 'Ukonczono wyszukiwanie. Poszukiwana fraza nie zostala odnaleziona.',
searchreplace_search_title : 'Znajdz',
searchreplace_replace_title : 'Znajdz/Zastap',
searchreplace_allreplaced : 'Wszystkie wystapienia poszukiwanej frazy zostaly zastapione. ',
searchreplace_findwhat : 'Znajdz',
searchreplace_replacewith : 'Zastap',
searchreplace_direction : 'Kierunek',
searchreplace_up : 'Do góry',
searchreplace_down : 'Do dolu',
searchreplace_case : 'Wielkosc liter',
searchreplace_findnext : 'Znajdz&nbsp;nastepny',
searchreplace_replace : 'Zastap',
searchreplace_replaceall : 'Zastap&nbsp;wszystkie',
searchreplace_cancel : 'Wyjdz'
});
