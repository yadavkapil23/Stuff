// PL lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Wstaw aktualna date',
inserttime_desc : 'Wstaw aktualny czas',
inserttime_months_long : new Array("Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien"),
inserttime_months_short : new Array("Stcz", "Lut", "Mar", "Kwi", "Maj", "Czer", "Lip", "Sier", "Wrze", "Paz", "List", "Grudz"),
inserttime_day_long : new Array("Niedziela", "Poniedzialek", "Wtorek", "Sroda", "Czwartek", "Piatek", "Sobota", "Niedziela"),
inserttime_day_short : new Array("Nie", "Pon", "Wto", "Sro", "Czw", "Pia", "Sob", "Nie")
});
