/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
iespell_desc : 'Spustit kontrolu pravopisu',
iespell_download : "ieSpell nedetekován. Klikněte na OK a otevřete stahovací stránku."
});

