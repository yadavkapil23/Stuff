/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložit/editovat vodorovný oddělovač',
insert_advhr_width : 'Šířka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestínovat'
});

