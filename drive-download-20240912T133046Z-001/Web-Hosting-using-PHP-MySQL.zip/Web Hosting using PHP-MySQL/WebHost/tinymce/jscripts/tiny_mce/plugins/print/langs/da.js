// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
print_desc : 'Udskriv'
});
