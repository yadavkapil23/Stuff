// pt_BR lang variables

tinyMCE.addToLang('',{
insert_flash : 'Inserir / editar Arquivo Flash',
insert_flash_file : 'Arquivo Flash (.swf)',
insert_flash_size : 'Tamanho',
insert_flash_list : 'Lista de arquivos Flash',
flash_props : 'Propriedades Flash'
});
