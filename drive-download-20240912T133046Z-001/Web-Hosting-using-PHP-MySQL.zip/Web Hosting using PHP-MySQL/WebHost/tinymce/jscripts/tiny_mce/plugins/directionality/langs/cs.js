/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Směr z leva doprava',
directionality_rtl_desc : 'Směr z prava doleva'
});

