// PL lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Uruchom sprawdzanie pisowni',
iespell_download : "Nie wykryto pluginu, kliknij aby przejsc do strony z pluginami."
});
