// pt_BR lang variables

tinyMCE.addToLang('',{
insert_emotions_title : 'Inserir Emoticon',
emotions_desc : 'Emoticons'
});
