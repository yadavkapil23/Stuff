// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
fullscreen_title : 'Fuldsk&#230;rmstilstand',
fullscreen_desc : 'T&#230;nd / sluk for fuldsk&#230;rm'
});
