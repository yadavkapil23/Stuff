/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
insert_flash : 'Vlo�it/editovat Flash Movie',
insert_flash_file : 'Flash soubor (.swf)',
insert_flash_size : 'Velikost',
insert_flash_list : 'Seznam',
flash_props : 'Vlastnosti Flash'
});
