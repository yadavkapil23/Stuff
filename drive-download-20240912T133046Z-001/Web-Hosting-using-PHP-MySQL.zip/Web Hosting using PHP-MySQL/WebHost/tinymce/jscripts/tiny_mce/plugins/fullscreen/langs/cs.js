/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
fullscreen_title : 'Na celou obrazovku',
fullscreen_desc : 'Přepnout na celou obrazovku'
});

