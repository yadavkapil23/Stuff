// NL lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Invoegen / wijzigen Horizontale lijn',
insert_advhr_width : 'Breedte',
insert_advhr_size : 'Hoogte',
insert_advhr_noshade : 'Geen schaduw'
});
