// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
fullscreen_title : 'Mode plein �cran',
fullscreen_desc : 'Basculer le mode plein �crans'
});
