// French lang variables by Laurent Dran

tinyMCE.addToLang('',{
insert_image_alt2 : 'Titre de l\'image',
insert_image_onmousemove : 'Image alternative',
insert_image_mouseover : 'Pour la souris au dessus',
insert_image_mouseout : 'Pour la souris en dehors'
});
