/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id$ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Změny, které jste udělal(a) budou ztraceny, jestliže opustíte tuto stránku.'
});

