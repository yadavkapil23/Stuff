<?php

include("includes/header.php");

echo "<center><span class=warning>You are now logged out!</span><br /><br />
        <a href=login.php>Log Back In</a></center>";

include("includes/footer.php");

?>
