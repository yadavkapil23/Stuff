<?php
include("includes/header.php");

echo "<center><span class=warning>Invalid Login!</span><br /><br />
        <a href=javascript:history.go(-1)>Try Again</a>.</center>";

include("includes/footer.php");
?>
