<?
include("includes/header.php");
include("includes/config.php");
?>
<table bgcolor="<?php echo $td_bg_color; ?>" width=75% align=center border=0 cellpadding=10 cellspacing=1><tr><td bgcolor="<?php echo $td_bg_color2; ?>">
<h2><? echo "$site_name" ?> terms and conditions: </h2>
<? echo "$site_name" ?>, <? echo "$site_name" ?> staff, and <? echo "$site_name" ?> users are not responsible for any content displayed on this site.

<p>Any illegal, immoral, degrading, disgusting, or any other type of obnoxious content is not tolerated and is therefore banned from this site.  If you decide to display any banned materials on this site, it will be deleted by the website administrator with or without notice.
<p>Gambling is not permitted on our server(s).  Therefore, you may not have any gambling content on your website.
<p>Phishing is not allowed on our server(s). If you are trying to advertise or take people to another website, do it somewhere else or some other way. 
<p>We will protect your information on this site only to the extent allowed by law.
<p>Your username and password on this website are encrypted, however there is still a chance that somebody could intercept your password.  This means that someone could possibly intercept your username and/or password.  Because of this, we recommend that you use a username and password that, in the event that it was intercepted, would not harm you.
<p>Your IP address, Operating System, Browser Information, and any other information that your computer sends us may be logged.  Keep this in mind if you try to do something illegal on this server!<p>These terms and conditions are subject to change with or without notice to you or anyone.
</fieldset>
</td></tr></table>

<br /><br />
<table align=center width=400 border=0><tr><td>
<fieldset>
<table width=100% align=center border=0>
 <tr>
  <td>

By clicking on the "I Agree" button, I acknowledge that I have read, understand the terms and conditions for this website.
  </td>
 </tr>
</table>
<br />
<table align=center border=0>
 <tr valign=top>
  <td width=50%>
<form action=reg.php>
<input type=submit value="I Agree">
</form>
  </td>
  <td width=50%>
<form action=index.php>
<input type=submit value="I Disagree">
</form>
  </td>
 </tr>
</table>
</fieldset>
</td></tr></table>

<? include("includes/footer.php"); ?>