-------------------------Blood Donor System-----------------------------------

System requirement:

SQL SERVER Express-2008


Run EXE .

Login information :

User Name :s
Password :s


Configure your SQL SERVER Connectionstring using UI.
 or  
update SQL SERVER ExpresS Path from  app.config if require


More info visit :www.bhansalisoft.com
Feel free to contact : info@bhansalisoft.com   