<div id="title">
    <h1><span style="color: #008000;">CLOTH SHOPPING</span></h1>
  </div>
  <div id="header"><img src="img/Header1.JPG" alt="header" width="770" height="200" /></div>
<div class="container">
    <ul id="navCircle">
      <li><a class="active" href="index.php">Home</a></li>
       <li><a href="User.php">User</a></li>
      <li><a href="Category.php">Category</a></li>
      
      <li><a href="Offers.php">Offers</a></li>
 <li><a href="Orders.php">Orders</a></li>
      <li><a href="Feedback.php">Feedback</a></li>
       <li><a href="Logout.php">Logout</a></li>
    </ul>
  </div>