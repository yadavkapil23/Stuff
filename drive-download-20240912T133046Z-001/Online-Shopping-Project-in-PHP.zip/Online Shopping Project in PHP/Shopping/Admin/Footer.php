<div id="footer">  &copy; 2014Online Cloth Shopping| Design by Jagruti Patel</div>
