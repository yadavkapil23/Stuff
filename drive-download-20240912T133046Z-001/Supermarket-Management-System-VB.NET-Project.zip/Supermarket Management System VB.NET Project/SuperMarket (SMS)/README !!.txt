!

Database password:  cc03bn01


Default username:
Username:  admin
Password:   admin


You can vote for this project if u like it, but if u don't like it, i'ts ok, don't vote.

Bye.